<div class="col-md-4">
    <h4 class="section-subtitle"><b>Geographical DF</b> Status </h4>
    <div class="panel minwidth nano has-scrollbar">
        <div class="dash-box-height nano-content dashboard">
			@include('dashboards.sections.map_xml')
		</div>
    </div>
</div>
