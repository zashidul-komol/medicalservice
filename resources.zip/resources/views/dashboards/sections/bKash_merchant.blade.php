<div class="col-md-4">
    <h4 class="section-subtitle"><b>Payment Information</h4>
    <div class="panel gallery-wrap">
         <div class="dash-box-height">
            <a href="{{ asset('storage/images/bkash-process.jpg') }}">
                <img class="img-responsive" src="{{ asset('storage/images/bkash.jpg') }}" alt="bKash">
            </a>
        </div>
    </div>
</div>