<div class="col-md-4">
    <h4 class="section-subtitle"><b>Regional DF</b> Status</h4>
    <div class="panel">
        <div class="panel-content">
            <div class="dash-box-height-2">
                <canvas id="bar-chart" width="400" height="310"></canvas>
            </div>
        </div>
    </div>
</div>