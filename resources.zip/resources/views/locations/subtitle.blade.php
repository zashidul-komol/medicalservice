<h4 class="section-subtitle">
	<b>
		@if ($param=='1')
			District
		@elseif($param=='2')
			Thana
		@else
			Division
		@endif
	</b>
</h4>
