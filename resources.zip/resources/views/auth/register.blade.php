@extends('layouts.admin',['className' => 'sign-in'])
@section('title', 'Register User')
@section('content')
<div class="content-header">
    <!-- leftside content header -->
    <div class="leftside-content-header">
        <ul class="breadcrumbs">
            <li><i class="fa fa-table" aria-hidden="true"></i><a href="#">User</a></li>
            <li><a>register</a></li>
        </ul>
    </div>
</div>
<div class="row animated fadeInRight">
    <form id="inline-validation" class="form-horizontal" method="POST" action="{{ route('register') }}">
        {{ csrf_field() }}
    
        <div class="col-sm-6">
            <h4 class="section-subtitle"><b>Employee Information</b></h4>
            
            <div class="panel">
                <div class="panel-content">
                    
                  <!-- Blank Page Start Here -->
                    <div class="active tab-pane" id="personal">
                        
                            <div class="form-group">
                              <label for="inputName" class="col-sm-3 ">Full Name</label>
                              <div class="col-sm-8">
                                <input id="name" type="text" class="form-control" name="name" value="{{ old('name') }}" required autofocus>

                                    @if ($errors->has('name'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('name') }}</strong>
                                        </span>
                                    @endif
                              </div>
                              
                            </div>
                            <div class="form-group{{ $errors->has('department_id') ? ' has-error' : '' }}">
                                <label for="department_id" class="col-sm-3 require">Department</label>
                                <div class="col-xs-8">
                                {{Form::select('department_id',$departments,old('department_id'),array('class' => 'form-control'))}}
                                </div>
                                 @if ($errors->has('department_id'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('department_id') }}</strong>
                                    </span>
                                @endif
                            </div>
                            <div class="form-group{{ $errors->has('designation_id') ? ' has-error' : '' }}">
                                <label for="designation_id" class="col-sm-3 require">Designation</label>
                                <div class="col-xs-8">
                                {{Form::select('designation_id',$designations,old('designation_id'),array('class' => 'form-control'))}}
                                </div>
                                 @if ($errors->has('designation_id'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('designation_id') }}</strong>
                                    </span>
                                @endif
                            </div>
                            <div class="form-group">
                              <label for="inputName" class="col-sm-3 ">Office ID</label>
                                <div class="col-xs-3">
                                    <div class="input-group">
                                       {{Form::text('office_id',null,array('class' => 'form-control'))}}
                                        {!! $errors->first('office_id', '<p class="text-danger">:message</p>' ) !!}
                                        
                                    </div>
                                </div>                               
                                <label for="inputName" class="col-sm-2 ">Gendar</label>
                                <div class="col-xs-3">
                                    <div class="input-group">
                                       {{Form::select('gendar',[''=>'--Please Select Gendar--']+['Male'=>'Male', 'Female'=>'Female'],null,array('class' => 'form-control'))}}
                                       
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                              <label for="inputName" class="col-sm-3 ">Mobile No.</label>
                                <div class="col-xs-4">
                                    <div class="input-group">
                                       {{Form::text('mobile',null,array('class' => 'form-control'))}}
                                        {!! $errors->first('mobile', '<p class="text-danger">:message</p>' ) !!}
                                        
                                    </div>
                                </div>                               
                                <label for="inputName" class="col-sm-2 ">Grade</label>
                                <div class="col-xs-2">
                                    <div class="input-group">
                                       {{Form::text('grade',null,array('class' => 'form-control'))}}
                                  {!! $errors->first('grade', '<p class="text-danger">:message</p>' ) !!}
                                       
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="inputName" class="col-sm-3 ">E-mail</label>
                                <div class="col-xs-8">
                                    {{Form::text('email',null,array('class' => 'form-control'))}}
                                  {!! $errors->first('email', '<p class="text-danger">:message</p>' ) !!}
                                </div>               
                            </div>
                            <div class="form-group">
                                <label for="inputName" class="col-sm-3 ">Emergency Contact No.</label>
                                <div class="col-xs-8">
                                    {{Form::text('emergency_contact',null,array('class' => 'form-control'))}}
                                    {!! $errors->first('emergency_contact', '<p class="text-danger">:message</p>' ) !!}
                                </div>               
                            </div>
                            <div class="form-group">
                                <label for="inputName" class="col-sm-3 ">NID</label>
                                <div class="col-xs-8">
                                    {{Form::text('nid',null,array('class' => 'form-control'))}}
                                     {!! $errors->first('nid', '<p class="text-danger">:message</p>' ) !!}
                                </div>               
                            </div>
                            <div class="form-group">
                                <label for="inputName" class="col-sm-3 ">Passport No.</label>
                                <div class="col-xs-8">
                                    {{Form::text('passportno',null,array('class' => 'form-control'))}}
                                     {!! $errors->first('passportno', '<p class="text-danger">:message</p>' ) !!}
                                </div>               
                            </div>
                            <div class="form-group">
                              <label for="inputName" class="col-sm-3 ">Maritial Status</label>
                                <div class="col-xs-4">
                                    <div class="input-group">
                                       {{Form::select('maritial_status',[''=>'--Please Select Maritial status--']+['Married'=>'Married', 'Unmarried'=>'Unmarried'],null,array('class' => 'form-control'))}}
                                        
                                    </div>
                                </div>                               
                                <label for="inputName" class="col-sm-2 ">Blood Group</label>
                                <div class="col-xs-2">
                                    <div class="input-group">
                                       {{Form::text('blood_group',null,array('class' => 'form-control'))}}
                                        {!! $errors->first('blood_group', '<p class="text-danger">:message</p>' ) !!}
                                       
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                              <label for="inputName" class="col-sm-3 ">Date of Birth</label>
                                <div class="col-xs-8">
                                    <div class="input-group">
                                        <span class="input-group-addon x-primary"><i class="fa fa-calendar"></i></span>
                                        {{Form::text('date_of_birth',null,array('class' => 'form-control datepicker'))}}
                                    </div>
                                </div>                               
                                
                            </div>
                            <div class="form-group">
                              <label for="inputName" class="col-sm-3 ">Date of Joining</label>
                                <div class="col-xs-8">
                                    <div class="input-group">
                                        <span class="input-group-addon x-primary"><i class="fa fa-calendar"></i></span>
                                        {{Form::text('date_of_joining',null,array('class' => 'form-control datepicker'))}}
                                    </div>
                                </div>                               
                            </div>
                            <div class="form-group">
                                <label for="inputName" class="col-sm-3 ">Present Address</label>
                                <div class="col-xs-8">
                                    {{Form::textarea('present_address',null,array('class' => 'form-control max-length','rows' => 3, 'cols' => 2,'maxlength'=>'150'))}}
                                  {!! $errors->first('present_address', '<p class="text-danger">:message</p>' ) !!}
                                </div>               
                            </div>
                            <h4 class="section-subtitle"><b>Permanent Address</b></h4>
                            
                                <div class="form-group{{ $errors->has('division_id') ? ' has-error' : '' }}">
                                    <label for="inputName" class="col-sm-3 require">Division</label>
                                    <div class="col-xs-8">
                                        {{Form::select('division_id',[''=>'Please Select Division']+$divisions->toArray(),null,array('class' => 'form-control','v-model'=>'division_id', '@change'=>'getDistricts'))}}
                                        {!! $errors->first('division_id', '<p class="text-danger">:message</p>' ) !!}
                                    </div>
                                </div>
                                <div class="form-group{{ $errors->has('district_id') ? ' has-error' : '' }}">
                                    <label for="inputName" class="col-sm-3 require">District</label>
                                    <div class="col-md-8">
                                        <select name="district_id" class="form-control col-sm-2" v-model="district_id" @change="getThanas">
                                            <option value="">Please Select District</option>
                                            <option v-for="(name,id) in districts" v-bind:value="id" v-text="name"></option>
                                        </select>
                                        {!! $errors->first('district_id', '<p class="text-danger">:message</p>' ) !!}
                                    </div>
                                </div>
                                <div class="form-group{{ $errors->has('thana_id') ? ' has-error' : '' }}">
                                    <label for="inputName" class="col-sm-3 require">Thana</label>
                                    <div class="col-md-8">
                                        <select name="thana_id" v-model="thana_id" class="form-control col-sm-2">
                                            <option value="">Please Select Thana</option>
                                            <option v-for="(name,id) in thanas" v-bind:value="id" v-text="name"></option>
                                        </select>
                                        {!! $errors->first('thana_id', '<p class="text-danger">:message</p>' ) !!}
                                    </div>
                                    
                            </div>
                            <div class="form-group">
                                <label for="inputName" class="col-sm-3 ">Address</label>
                                <div class="col-xs-8">
                                    {{Form::textarea('permanent_address',null,array('class' => 'form-control max-length','rows' => 3, 'cols' => 2,'maxlength'=>'150'))}}
                                  {!! $errors->first('permanent_address', '<p class="text-danger">:message</p>' ) !!}
                                </div>               
                            </div>
                           
                        
                      <!-- /.form-horizontal -->
                    </div>

                  <!-- Blank Page End Here --> 
                </div>
            </div>
        </div>
        <div class="col-sm-6">
            <h4 class="section-subtitle"><b>Family Information</b></h4>
            
            <div class="panel">
                <div class="panel-content">

                  <!-- Blank Page Start Here -->
                  <div class="active tab-pane" id="personal">
                      
                            <div class="form-group">
                              <label for="inputName" class="col-sm-3 ">Father's Name</label>
                              <div class="col-sm-8">
                                {{Form::text('fathers_name',null,array('class' => 'form-control'))}}
                                  {!! $errors->first('fathers_name', '<p class="text-danger">:message</p>' ) !!}
                              </div>
                              
                            </div>
                            <div class="form-group">
                                <label for="inputName" class="col-sm-3 ">Occupation</label>
                                <div class="col-xs-8">
                                    {{Form::text('fathers_occupation',null,array('class' => 'form-control'))}}
                                     {!! $errors->first('fathers_occupation', '<p class="text-danger">:message</p>' ) !!}
                                </div>               
                            </div>
                            <div class="form-group">                          
                              <label for="inputName" class="col-sm-3 ">Mother's Name</label>
                              <div class="col-xs-8">
                                 {{Form::text('mothers_name',null,array('class' => 'form-control'))}}
                                  {!! $errors->first('mothers_name', '<p class="text-danger">:message</p>' ) !!} 
                              </div>
                            </div>
                            <div class="form-group">
                                <label for="inputName" class="col-sm-3 ">Occupation</label>
                                <div class="col-xs-8">
                                    {{Form::text('mothers_occupation',null,array('class' => 'form-control'))}}
                                     {!! $errors->first('mothers_occupation', '<p class="text-danger">:message</p>' ) !!}
                                </div>               
                            </div>
                            <div class="form-group">                          
                              <label for="inputName" class="col-sm-3 ">Spouse Name</label>
                              <div class="col-xs-8">
                                 {{Form::text('spouse_name',null,array('class' => 'form-control'))}}
                                  {!! $errors->first('spouse_name', '<p class="text-danger">:message</p>' ) !!} 
                              </div>
                            </div>
                            <div class="form-group">
                                <label for="inputName" class="col-sm-3 ">Occupation</label>
                                <div class="col-xs-8">
                                    {{Form::text('spouse_occupation',null,array('class' => 'form-control'))}}
                                     {!! $errors->first('spouse_occupation', '<p class="text-danger">:message</p>' ) !!}
                                </div>               
                            </div>
                            <div class="form-group">
                              <label for="inputName" class="col-sm-3 ">No. of Brother's</label>
                                <div class="col-xs-3">
                                    <div class="input-group">
                                       {{Form::text('no_of_brothers',null,array('class' => 'form-control'))}}
                                  {!! $errors->first('no_of_brothers', '<p class="text-danger">:message</p>' ) !!} 
                                        
                                    </div>
                                </div>                               
                                <label for="inputName" class="col-sm-2 ">Sister's</label>
                                <div class="col-xs-3">
                                    <div class="input-group">
                                       {{Form::text('no_of_sisters',null,array('class' => 'form-control'))}}
                                  {!! $errors->first('no_of_sisters', '<p class="text-danger">:message</p>' ) !!} 
                                       
                                    </div>
                                </div>
                            </div>
                            
                    <!-- /.form-horizontal -->
                  </div>

                  <!-- Blank Page End Here --> 
                </div>
            </div>
        </div>
        <div class="col-sm-6">
            <h4 class="section-subtitle"><b>Education</b></h4>
            
            <div class="panel">
                <div class="panel-content">

                  <!-- Blank Page Start Here -->
                  <div class="active tab-pane" id="personal">
                            <div class="form-group">
                              <label for="inputName" class="col-sm-3 ">Highest Degree</label>
                              <div class="col-sm-8">
                                {{Form::text('highest_degree',null,array('class' => 'form-control'))}}
                                  {!! $errors->first('highest_degree', '<p class="text-danger">:message</p>' ) !!}
                              </div>
                              
                            </div>
                               
                    <!-- /.form-horizontal -->
                  </div>

                  <!-- Blank Page End Here --> 
                </div>
            </div>
        </div>
        <div class="col-sm-6">
            <h4 class="section-subtitle"><b>Employment History</b></h4>
            
            <div class="panel">
                <div class="panel-content">

                  <!-- Blank Page Start Here -->
                  <div class="active tab-pane" id="personal">
                            <div class="form-group">
                              <label for="inputName" class="col-sm-3 ">Year's of Experiance</label>
                              <div class="col-sm-8">
                                {{Form::text('years_of_experiances',null,array('class' => 'form-control'))}}
                                  {!! $errors->first('years_of_experiances', '<p class="text-danger">:message</p>' ) !!}
                              </div>
                              
                            </div>
                            <div class="form-group">
                              <label for="inputName" class="col-sm-3 ">Last Company</label>
                              <div class="col-sm-8">
                                {{Form::text('last_company',null,array('class' => 'form-control'))}}
                                  {!! $errors->first('last_company', '<p class="text-danger">:message</p>' ) !!}
                              </div>
                              
                            </div>
                            <div class="form-group">
                              <label for="inputName" class="col-sm-3 ">Position</label>
                              <div class="col-sm-8">
                                {{Form::text('last_position',null,array('class' => 'form-control'))}}
                                  {!! $errors->first('last_position', '<p class="text-danger">:message</p>' ) !!}
                              </div>
                              
                            </div>
                            <div class="form-group">
                              <label for="inputName" class="col-sm-3 ">Department</label>
                              <div class="col-sm-8">
                                {{Form::text('last_department',null,array('class' => 'form-control'))}}
                                  {!! $errors->first('last_department', '<p class="text-danger">:message</p>' ) !!}
                              </div>
                              
                            </div>
                            <div class="form-group">
                              <label for="inputName" class="col-sm-3 ">Duration</label>
                              <div class="col-sm-8">
                                {{Form::text('duration',null,array('class' => 'form-control'))}}
                                  {!! $errors->first('duration', '<p class="text-danger">:message</p>' ) !!}
                              </div>
                              
                            </div>
                               
                    <!-- /.form-horizontal -->
                  </div>

                  <!-- Blank Page End Here --> 
                </div>
            </div>
        </div>
        <div class="col-sm-6">
            <h4 class="section-subtitle"><b>Children's Information</b></h4>
            
            <div class="panel">
                <div class="panel-content">

                  <!-- Blank Page Start Here -->
                  <div class="active tab-pane" id="personal">
                                                  
                            <div class="form-group">
                                <label for="inputName" class="col-sm-3 ">Child Name</label>
                                <div class="col-xs-8">
                                    {{Form::text('child_name',null,array('class' => 'form-control'))}}
                                     {!! $errors->first('child_name', '<p class="text-danger">:message</p>' ) !!}
                                </div>               
                            </div>
                            <div class="form-group">
                              <label for="inputName" class="col-sm-3 ">Date of Birth</label>
                                <div class="col-xs-3">
                                    <div class="input-group">
                                       {{Form::text('child_DOB',null,array('class' => 'form-control'))}}
                                        {!! $errors->first('child_DOB', '<p class="text-danger">:message</p>' ) !!} 
                                        
                                    </div>
                                </div>                               
                                <label for="inputName" class="col-sm-2 ">Gendar</label>
                                <div class="col-xs-3">
                                    <div class="input-group">
                                       {{Form::text('child_gendar',null,array('class' => 'form-control'))}}
                                        {!! $errors->first('child_gendar', '<p class="text-danger">:message</p>' ) !!} 
                                       
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="inputName" class="col-sm-3 ">Occupation</label>
                                <div class="col-xs-8">
                                    {{Form::text('child_occupation',null,array('class' => 'form-control'))}}
                                     {!! $errors->first('child_occupation', '<p class="text-danger">:message</p>' ) !!}
                                </div>               
                            </div>
                            <div class="form-group">
                                <label for="inputName" class="col-sm-3 ">Education</label>
                                <div class="col-xs-8">
                                    {{Form::text('child_education',null,array('class' => 'form-control'))}}
                                     {!! $errors->first('child_education', '<p class="text-danger">:message</p>' ) !!}
                                </div>               
                            </div>
                            
                    <!-- /.form-horizontal -->
                  </div>

                  <!-- Blank Page End Here --> 
                </div>
            </div>
        </div>
        <div class="col-sm-6">
            <h4 class="section-subtitle"><b>User Registration</b></h4>
            <div class="panel">
                <div class="panel-content">
                      
                        
                            <div class="form-group{{ $errors->has('role_id') ? ' has-error' : '' }}">
                                <label for="role_id" class="col-sm-3 require">Role</label>
                                <div class="col-md-8">
                                {{Form::select('role_id',$roles,old('role_id'),array('class' => 'form-control'))}}
                                </div>
                                @if ($errors->has('role_id'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('role_id') }}</strong>
                                    </span>
                                @endif
                            </div>
                            <div class="form-group">
                                <label class="col-sm-3 require">User ID:</label>
                                <div class="col-md-8">
                                       {{Form::text('office_id',null,array('class' => 'form-control'))}}
                                        {!! $errors->first('office_id', '<p class="text-danger">:message</p>' ) !!} 
                                        
                                    </div>
                            </div>
                            <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                                <label for="password" class="col-sm-3 require">Password</label>

                                <div class="col-md-8">
                                    <input id="password" type="password" class="form-control" name="password" required>

                                    @if ($errors->has('password'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('password') }}</strong>
                                        </span>
                                    @endif
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="password-confirm" class="col-sm-3 require">Confirm Password</label>
                                <div class="col-md-8">
                                    <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                                </div>
                            </div>
                             <div class="form-group">
                                <label for="status" class="col-sm-3 require">Status</label>
                                <div class="col-md-8">
                                {{Form::select('status',config('myconfig.status'),old('status'),array('class' => 'form-control'))}}
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-md-8 col-md-offset-3">
                                    <button type="submit" class="btn btn-primary">
                                        Register
                                    </button>
                                </div>
                            </div>
                        
                        
                </div>
            </div>
        </div>
    </form>
</div>
@endsection
@section('css')
<style>
    .fa-sort-desc{
        cursor: pointer;
        font-size: 20px;
    }
    .fa-sort-desc.open{
        transform: rotate(90deg);
    }
    .distributor{
        display: none;
        list-style: none;
    }

</style>
@stop
@section('script')
@include('common_pages.max_length')
<script>
$(document).on('click','.fa-sort-desc',function(){
    $(this).next('ul.distributor').slideToggle();
    $(this).toggleClass('open');
});

$(document).on('click','.depots',function(){
    var tis=$(this);
    var obj=tis.parents('.input-container').find('ul.distributor');
    if(tis.is(':checked')){
        var lgth=obj.find("input:checkbox:checked").length;
        if(!lgth){
            obj.find("input:checkbox").prop('checked',true);
        }
    }else{
        obj.find("input:checkbox").prop('checked',false);
    }
});

$(document).on('click','.distributors',function(){
    var idd=$(this).data('parent');
   if($('.depot-'+idd+':checked').length){
        $('#depot-'+idd).prop('checked',true);
   }else{
        $('#depot-'+idd).prop('checked',false);
   }
});

$(document).ready(function(e){
    $("#checkoruncheck").change(function () {
        $("input:checkbox").prop('checked', $(this).prop("checked"));
    });
});
</script>
@stop
@section('vuescript')
<script>
    laravelObj.division_id='{{ old('division_id') }}';
    laravelObj.district_id='{{ old('district_id') }}';
    laravelObj.thana_id='{{ old('thana_id') }}';
</script>
@stop
@component('common_pages.selectize')
    @include('common_pages.max_length')
    <script src="{{ asset('vendor/bootstrap_date-picker/js/bootstrap-datepicker.min.js') }}"></script>
    <script type="text/javascript">

        $('.datepicker').datepicker({ format: "yyyy-mm-dd",todayHighlight: true,autoclose:true});

    </script>
    @slot('css')
     <!--Date picker-->
     <link rel="stylesheet" href="{{ asset('vendor/bootstrap_date-picker/css/bootstrap-datepicker3.min.css') }}">
    @endslot
@endcomponent

