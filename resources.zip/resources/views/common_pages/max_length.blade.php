<script src="{{ asset('vendor/bootstrap_max-lenght/bootstrap-maxlength.js') }}"></script>
<script>
	//max limit controll for input
	$('.max-length').maxlength({
	    alwaysShow: true,
	    placement: 'top-right-inside'
	});
</script>
