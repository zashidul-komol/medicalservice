<div class="design-develop">
   Designed & Developed by <a href="#" target="_blank">POLAR IT.</a>
</div>