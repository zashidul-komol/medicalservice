 <div class="header-section" id="search-headerbox">
    <input type="text" name="search" id="search" placeholder="Search...">
    <i class="fa fa-search search" id="search-icon" aria-hidden="true"></i>
    <div class="header-separator"></div>
</div>