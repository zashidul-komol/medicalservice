<div class="gallery-wrap">
    <div class="row">
        <div class="col-xs-6 col-md-3">
            <a href="{{ asset('images/helsinki-lg.jpg') }}" title="By John Doe">
                <img alt="first photo" src="{{ asset('storage/images/helsinki.jpg') }}" class="img-responsive">
            </a>
        </div>
        <div class="col-xs-6 col-md-3">
            <a href="{{ asset('storage/images/helsinki-lg.jpg') }}" title="By John Doe">
                <img alt="second photo" src="{{ asset('storage/images/helsinki.jpg') }}" class="img-responsive">
            </a>
        </div>
        <div class="col-xs-6 col-md-3">
            <a href="{{ asset('images/helsinki-lg.jpg') }}" title="By John Doe">
                <img alt="third photo" src="{{ asset('storage/images/helsinki.jpg') }}" class="img-responsive">
            </a>
        </div>
        <div class="col-xs-6 col-md-3">
            <a href="{{ asset('images/helsinki-lg.jpg') }}" title="By John Doe">
                <img alt="fourth photo" src="{{ asset('storage/images/helsinki.jpg') }}" class="img-responsive">
            </a>
        </div>
        <div class="col-xs-6 col-md-3">
            <a href="{{ asset('images/helsinki-lg.jpg') }}" title="By John Doe">
                <img alt="fifth photo" src="{{ asset('storage/images/helsinki.jpg') }}" class="img-responsive">
            </a>
        </div>
        <div class="col-xs-6 col-md-3">
            <a href="{{ asset('images/helsinki-lg.jpg') }}" title="By John Doe">
                <img alt="sixth photo" src="{{ asset('storage/images/helsinki.jpg') }}" class="img-responsive">
            </a>
        </div>
        <div class="col-xs-6 col-md-3">
            <a href="{{ asset('images/helsinki-lg.jpg') }}" title="By John Doe">
                <img alt="seventh photo" src="{{ asset('storage/images/helsinki.jpg') }}" class="img-responsive">
            </a>
        </div>
        <div class="col-xs-6 col-md-3">
            <a href="{{ asset('images/helsinki-lg.jpg') }}" title="By John Doe">
                <img alt="eighth photo" src="{{ asset('storage/images/helsinki.jpg') }}" class="img-responsive">
            </a>
        </div>
    </div>
</div>
