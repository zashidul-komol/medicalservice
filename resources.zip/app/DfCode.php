<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DfCode extends Model {
	protected $guarded = array('id');
	const UPDATED_AT=null;
}
