<?php

namespace App\Http\Controllers;

class ReportsController extends Controller {
	//
}
