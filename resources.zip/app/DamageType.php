<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DamageType extends Model {
	public $timestamps = false;
	protected $guarded = array('id');
}
